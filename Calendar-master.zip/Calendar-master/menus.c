/******************************************************************************
 * File Name: menus.c
 * Authors:
 * Last modified: 2017-12-02
 * Revision:  v0.1
 * COMMENTS: Implements the MENU functions
 *****************************************************************************/
#include "menus.h"
#include "date_validation.h"

/*****************************************************************************
* menuPrincipal
* Arguments: none
* Returns: none
*****************************************************************************/
void menuPrincipal (void)
{
    int pressed_key = 0;
    char c;

    /* Main menu*/
    do {
        system("clear");
        printf("1. Validação de data\n");
        printf("2. Coleção de datas\n");
        printf("3. Operações com datas\n");
        printf("4. Calcular o dia da semana\n");
        printf("5. Gestão de Calendário\n");
        printf("6. Terminar o programa\n");
    } while ((scanf("%d%c", &pressed_key, &c) != 2 || c != '\n') && cleanStdin());

    switch (pressed_key)
    {
        case 1:
            validacaoData();
            break;
        case 2:
            colecaoDatas();
            break;
        case 3:
            operacoesDatas();
            break;
        case 4:
            /*Insert function*/
            break;
        case 5:
            gestaoCalendario();
            break;
        case 6:
            return;
        default:
            /* DO NOTHING*/
            break;
    }

    menuPrincipal();
}

/*****************************************************************************
* validacaoData
* Arguments: none
* Returns: none
*****************************************************************************/
void validacaoData (void)
{
    int pressed_key = 0;
    int day = -1, month = -1, year = -1;
    char c;
    do {
        system("clear");
        printf("1. Ler data\n");
        printf("2. Verificar formatação de data\n");
        printf("3. Verificar validade da data\n");
        printf("4. Apresentar uma data no formato “dd/mm/aaaa”\n");
        printf("5. Apresentar uma data no formato dd “ de ” mm “ de ” aaaa \n");
        printf("6. Apresentar uma data no formato dd “ de ” mês “ de ” aaaa \n");
        printf("7. Voltar ao menu anterior\n");
    } while ((scanf("%d%c", &pressed_key, &c) != 2 || c != '\n') && cleanStdin());

    switch (pressed_key)
    {
        case 1:
            readDate(&day, &month, &year);
            break;
        case 2:
            verifyFormat();
            break;
        case 3:
            validateDate(day, month, year);
            break;
        case 4:
            dateFormat1(day, month, year);
            break;
        case 5:
            dateFormat2(day, month, year);
            break;
        case 6:
            dateFormat3(day, month, year);
            break;
        case 7:
            return;
        default:
            /* DO NOTHING*/
            break;
    }

    validacaoData();
}

/*****************************************************************************
* colecaoDatas
* Arguments: none
* Returns: none
*****************************************************************************/
void colecaoDatas (void)
{
    int pressed_key = 0;
    char c;
    do {
        system("clear");
        printf("1. Inserir uma data num vetor de datas\n");
        printf("2. Mostrar o vetor de datas\n");
        printf("3. Preencher um vetor com datas aleatórias válidas\n");
        printf("4. Verificar se uma data existe no vetor\n");
        printf("5. Mostrar a data maior do vetor e a sua posição\n");
        printf("6. Mostrar a data menor do vetor e a sua posição\n");
        printf("7. Ordenar as datas do vetor por ordem crescente\n");
        printf("8. Ordenar as datas do vetor por ordem decrescente\n");
        printf("9. Voltar ao menu anterior\n");
    } while ((scanf("%d%c", &pressed_key, &c) != 2 || c != '\n') && cleanStdin());


    switch (pressed_key)
    {
        case 1:
            /*Insert function*/
            break;
        case 2:
            /*Insert function*/
            break;
        case 3:
            /*Insert function*/
            break;
        case 4:
            /*Insert function*/
            break;
        case 5:
            /*Insert function*/
            break;
        case 6:
            /*Insert function*/
            break;
        case 7:
            /*Insert function*/
            break;
        case 8:
            /*Insert function*/
            break;
        case 9:
            return;
        default:
            /* DO NOTHING*/
            break;
    }

    colecaoDatas();
}

/*****************************************************************************
* operacaoDatas
* Arguments: none
* Returns: none
*****************************************************************************/
void operacoesDatas (void)
{
    int pressed_key = 0;
    char c;
    do {
        system("clear");
        printf("1. Verificar se data é de um ano bissexto\n");
        printf("2. Mostrar a data de hoje\n");
        printf("3. Adicionar n dias a uma determinada data\n");
        printf("4. Remover n dias a uma determinada data\n");
        printf("5. Comparar duas datas\n");
        printf("6. Mostrar diferença entre duas datas(em dias)\n");
        printf("7. Mostrar quantos dias úteis existem entre duas datas\n");
        printf("8. Mostrar o horário Unix de uma data\n");
        printf("9. Voltar ao menu anterior\n");
    } while ((scanf("%d%c", &pressed_key, &c) != 2 || c != '\n') && cleanStdin());

    switch (pressed_key)
    {
        case 1:
            /*Insert function*/
            break;
        case 2:
            /*Insert function*/
            break;
        case 3:
            /*Insert function*/
            break;
        case 4:
            /*Insert function*/
            break;
        case 5:
            /*Insert function*/
            break;
        case 6:
            /*Insert function*/
            break;
        case 7:
            /*Insert function*/
            break;
        case 8:
            /*Insert function*/
            break;
        case 9:
            return;
        default:
            /* DO NOTHING*/
            break;
    }

    operacoesDatas();
}

/*****************************************************************************
* gestaoCalendario
* Arguments: none
* Returns: none
*****************************************************************************/
void gestaoCalendario (void)
{
    int pressed_key = 0;
    char c;
    do {
        system("clear");
        printf("1. Criar um calendário para um determinado ano\n");
        printf("2. Adicionar um evento ao calendário\n");
        printf("3. Alterar informação de um evento\n");
        printf("4. Calcular e mostrar a data da Páscoa para o ano do calendário\n");
        printf("5. Calcular e mostrar os feriados ou dias festivos associados à data da Páscoa\n");
        printf("6. Mostrar todos os eventos\n");
        printf("7. Mostrar os eventos do tipo feriado móvel\n");
        printf("8. Mostrar os eventos do tipo feriado fixo\n");
        printf("9. Mostrar os eventos do tipo dia festivo\n");
        printf("10. Mostrar outros eventos\n");
        printf("11. Calcular e mostrar os dias da mudança de hora\n");
        printf("12. Procurar e mostrar o evento marcado numa data do calendário\n");
        printf("13. Procurar e mostrar informação de uma data do calendário\n");
        printf("14. Listar calendário\n");
        printf("15. Voltar ao menu anterior\n");

    } while ((scanf("%d%c", &pressed_key, &c) != 2 || c != '\n') && cleanStdin());

    switch (pressed_key)
    {
        case 1:
            /*Insert function*/
            break;
        case 2:
            /*Insert function*/
            break;
        case 3:
            /*Insert function*/
            break;
        case 4:
            /*Insert function*/
            break;
        case 5:
            /*Insert function*/
            break;
        case 6:
            /*Insert function*/
            break;
        case 7:
            /*Insert function*/
            break;
        case 8:
            /*Insert function*/
            break;
        case 9:
            /*Insert function*/
            break;
        case 10:
            /*Insert function*/
            break;
        case 11:
            /*Insert function*/
            break;
        case 12:
            /*Insert function*/
            break;
        case 13:
            /*Insert function*/
            break;
        case 14:
            /*Insert function*/
            break;
        case 15:
            return;
        default:
            /* DO NOTHING*/
            break;
    }

    gestaoCalendario();
}
