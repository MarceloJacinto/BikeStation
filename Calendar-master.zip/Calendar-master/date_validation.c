/******************************************************************************
 * File Name: date_validation.c
 * Authors:
 * Last modified: 2017-12-02
 * Revision:  v0.1
 * COMMENTS: Implements the functions related to the date validation menu
 *****************************************************************************/
#include "date_validation.h"

/*****************************************************************************
* readDate
* Arguments: int* day, int* month, int* year
* Comments: Reads a date and saves it
* Returns: void
*****************************************************************************/
void readDate(int* day, int* month, int* year)
{
    char c;

    do
    {
       printf("Insert a day!\n");
    }while((scanf("%d%c", day, &c) != 2 || c != '\n') && cleanStdin());
    c = 'a';

    do
    {
       printf("Insert a month!\n");
    }while((scanf("%d%c", month, &c) != 2 || c != '\n') && cleanStdin());
    c = 'a';

    do
    {
       printf("Insert a year!\n");
    }while((scanf("%d%c", year, &c) != 2 || c != '\n') && cleanStdin());

    printf("Data Guardada!\n");
    pressKey();
}

/*****************************************************************************
* verifyFormat
* Arguments: none
* Comments: Checks if a date is in the dd/mm/yyyy format
* Returns: void
*****************************************************************************/
void verifyFormat()
{
    int ret = -1;
    char str[20];

    while(ret!=1)
    {
        printf("Insert a date!\n");
        ret = scanf("%s", str);
    }

    /*It means the date inserted is longer than possible*/
    if(str[10] != '\0')
    {
        printf("The date is not in the dd/mm/yyyy format!\n");
        pressKey();
        return;
    }

    /*If any os the caracters doesn't correspond the the dd/mm/yyyy format*/
    /*then we know the date isn't in that format*/
    if(isNumber(str[0]) == FALSE || isNumber(str[1]) == FALSE || str[2] != '/'
    || isNumber(str[3]) == FALSE || isNumber(str[4]) == FALSE || str[5] != '/'
    || isNumber(str[6]) == FALSE || isNumber(str[7]) == FALSE ||
    isNumber(str[8]) == FALSE || isNumber(str[9]) == FALSE)
    {
        printf("The date is not in the dd/mm/yyyy format!\n");
        pressKey();
        return;
    }

    printf("The date is in the dd/mm/yyyy format!\n");
    pressKey();
}

/*****************************************************************************
* validateDate
* Arguments: int day, int month, int year
* Comments: Checks if a date is valid
* Returns: void
*****************************************************************************/
void validateDate(int day, int month, int year)
{
    if(year < 0 || month <= 0 || month > 12 || day <= 0 || day > 31)
    {
        printf("The date is invalid!\n");
        pressKey();
        return;
    }

    if(month == FEV)
    {
        if(day >= 30)
        {
            printf("The date is invalid!\n");
            pressKey();
            return;
        }
        if(day <= 28)
        {
            printf("The date is valid!\n");
            pressKey();
            return;
        }
        /*The only case left is day == 29, which is valid if we are in a leap year*/
        if(isLeapYear(year) == TRUE)
        {
            printf("The date is valid!\n");
            pressKey();
            return;
        }
        else
        {
            printf("The date is invalid!\n");
            pressKey();
            return;
        }
    }

    if(month == ABR || month == JUN || month == SET || month == NOV)
    {
        if(day == 31)
        {
            printf("The date is invalid!\n");
            pressKey();
            return;
        }
    }

    printf("The date is valid!\n");
    pressKey();
}

/*****************************************************************************
* dateFormat1
* Arguments: int day, int month, int year
* Comments: Displays a date in the format dd/mm/yyyy
* Returns: void
*****************************************************************************/
void dateFormat1(int day, int month, int year)
{
    printf("%d/%d/%d\n", day, month, year);
    pressKey();
}

/*****************************************************************************
* dateFormat2
* Arguments: int day, int month, int year
* Comments: Displays a date in the format dd of mm of yyyy
* Returns: void
*****************************************************************************/
void dateFormat2(int day, int month, int year)
{
    printf("%d of %d of %d\n", day, month, year);
    pressKey();
}

/*****************************************************************************
* dateFormat3
* Arguments: int day, int month, int year
* Comments: Displays a date in the format dd of Month of yyyy
* Returns: void
*****************************************************************************/
void dateFormat3(int day, int month, int year)
{
    if(month <= 0 || month > 12)
    {
        printf("Invalid month!\n");
        return;
    }

    printf("%d of ", day);

    if(month == 1) printf("January of ");
    else if(month == 2) printf("February of ");
    else if(month == 3) printf("March of ");
    else if(month == 4) printf("April of ");
    else if(month == 5) printf("May of ");
    else if(month == 6) printf("June of ");
    else if(month == 7) printf("July of ");
    else if(month == 8) printf("August of ");
    else if(month == 9) printf("September of ");
    else if(month == 10) printf("October of ");
    else if(month == 11) printf("November of ");
    else printf("December of ");

    printf("%d\n", year);

    pressKey();
}
