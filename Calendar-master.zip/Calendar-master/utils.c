/******************************************************************************
 * File Name: utils.h
 * Authors:
 * Last modified: 2017-12-02
 * Revision:  v0.1
 * COMMENTS: declares general purpose functions and dataStructs
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>

/*****************************************************************************
* isNumber
* Arguments: char a
* Returns:  is a correspondes to a number. 0 otherwise
*****************************************************************************/
int isNumber(char a)
{
    if('0' <= a && a <= '9') return 1;
    return 0;
}

/*****************************************************************************
* isLeapYear
* Arguments: int year
* Returns: 1 if the year is a leap year. 0 otherwise
*****************************************************************************/
int isLeapYear(int year)
{
    if(year%4 != 0) return 0;
    else if(year%100 != 0) return 1;
    else if(year%400 != 0) return 0;
    else return 1;
}

/*****************************************************************************
* pressKey
* Arguments:
* Returns: void
*****************************************************************************/
void pressKey()
{
    int ret = -1, n = -1;
    while(ret != 1 || n != 1)
    {
        printf("Write 1 and press enter to continue!\n");
        ret = scanf("%d", &n);
    }
}

/*****************************************************************************
* cleanStdin
* Arguments: none
* Comments: Clean the stdin to avoid bugs when chars are inserted instead of ints
* Returns: void
*****************************************************************************/
int cleanStdin()
{
    while(getchar() != '\n');
    return 1;
}
