/******************************************************************************
 * File Name: main.h
 * Authors:    --Um tipo que nao deveria ter feito o trabalho cof cof--
 * Last modified: 2017-12-02
 * Revision:  v0.1
 * COMMENTS: implements main function
 *****************************************************************************/
#include "menus.h"

int main (void)
{
    menuPrincipal();
    return 0;
}
