/******************************************************************************
 * File Name: menus.h
 * Authors:
 * Last modified: 2017-12-02
 * Revision:  v0.1
 * COMMENTS: declares all MENU functions
 *****************************************************************************/
 #include <stdio.h>
 #include <stdlib.h>

void menuPrincipal (void);
void colecaoDatas (void);
void validacaoData (void);
void operacoesDatas (void);
void gestaoCalendario (void);
