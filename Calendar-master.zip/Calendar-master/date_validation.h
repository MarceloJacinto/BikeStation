/******************************************************************************
 * File Name: date_validation.h
 * Authors:
 * Last modified: 2017-12-02
 * Revision:  v0.1
 * COMMENTS: Declares all the date validation menus
 *****************************************************************************/
#include "utils.h"

void readDate(int* day, int* month, int* year);
void verifyFormat();
void validateDate(int day, int month, int year);
void dateFormat1(int day, int month, int year);
void dateFormat2(int day, int month, int year);
void dateFormat3(int day, int month, int year);
